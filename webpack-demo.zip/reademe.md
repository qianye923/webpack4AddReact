参考地址  https://segmentfault.com/a/1190000015592264?utm_source=tag-newest

服务器打开  http://127.0.0.1:9999/main_guide.html   一定要加生成的文件夹的名字






搭建webpack 后

  cnpm i react react-dom -S


  还要安装 
    babel-plugin-transform-decorators-legacy //支持修饰符语法 @connect
    babel-preset-react   //解析react语法
    react-hot-loader     //react热更新需要在babelrc做配置




     日志
      a20191206    netbar_admin_task.html